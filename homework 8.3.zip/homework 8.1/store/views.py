from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView

from .models import Book, Genre
from .serializers import (BookSerializer, BookSerializerForAdmin,
                          GenreSerializer)


class GenreAPIView(ListCreateAPIView):
    queryset = Genre.objects.all()
    serializer_class = GenreSerializer


class GenreRetrieveAPIView(RetrieveUpdateDestroyAPIView):
    queryset = Genre.objects.all()
    serializer_class = GenreSerializer
    lookup_field = "pk"
    lookup_url_kwarg = "genre_id"


class BookAPIView(ListCreateAPIView):
    serializer_class = BookSerializer

    def get_queryset(self):
        genre_id = self.kwargs.get("genre_id")

        if genre_id:
            books = Book.objects.filter(genre_id=genre_id)
        else:
            books = Book.objects.all()
        return books

    def get_serializer_class(self):
        if self.request.user.is_staff:
            return BookSerializerForAdmin
        return BookSerializer


class BookRetrieveAPIView(RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    lookup_field = "pk"
    lookup_url_kwarg = "book_id"

    def get_serializer_class(self):
        if self.request.user.is_staff:
            return BookSerializerForAdmin
        return BookSerializer


