from django.urls import path

from store.views import BookAPIView, GenreAPIView

urlpatterns = [
    path('Books/', BookAPIView.as_view()),
    path('Books/genre/<int:genre_id>/', BookAPIView.as_view()),
    path('Books/<int:pk>/', BookAPIView.as_view()),
    path('Genre/', GenreAPIView.as_view()),
    path('Genres/<int:pk>/', GenreAPIView.as_view()),
]


